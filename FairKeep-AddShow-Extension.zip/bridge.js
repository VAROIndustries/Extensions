// Content script on fairkeep.app's import screen. Collects this tab's capture
// from the background worker and hands it to the page with a same-origin
// postMessage. Re-posts until the page acknowledges, because React may mount
// its listener before or after this script runs.

(async () => {
  if (!new URLSearchParams(location.search).has('import')) return;
  const capture = await chrome.runtime.sendMessage({ type: 'get-capture' });
  if (!capture) return;

  let acked = false;
  const send = () => window.postMessage({ type: 'fairkeep-capture', capture }, location.origin);

  window.addEventListener('message', (e) => {
    if (e.origin !== location.origin) return;
    if (e.data?.type === 'fairkeep-got') acked = true;
    else if (e.data?.type === 'fairkeep-ready' && !acked) send();
  });

  send();
  for (let i = 0; i < 20 && !acked; i++) {
    await new Promise((r) => setTimeout(r, 500));
    if (!acked) send();
  }
})();
