// Toolbar click → capture the page you are on → open FairKeep's import screen.
//
// Nothing is read until you click, and only from that one tab (activeTab).
// The capture waits in session storage, keyed to the FairKeep tab it was made
// for, until bridge.js on that tab collects it; it is deleted on collection.

const IMPORT_URL = 'https://fairkeep.app/dashboard/applications/new?import=1';

// Runs inside the show's page. Must be self-contained (it is serialised).
function capturePage() {
  const meta = (sel) => document.querySelector(sel)?.getAttribute('content') || '';
  const jsonLd = [];
  for (const s of document.querySelectorAll('script[type="application/ld+json"]')) {
    try { jsonLd.push(JSON.parse(s.textContent)); } catch { /* malformed on the site — skip */ }
    if (jsonLd.length >= 20) break;
  }
  return {
    url: location.href,
    title: document.title,
    metaDescription: meta('meta[name="description"]'),
    og: { 'og:title': meta('meta[property="og:title"]') },
    jsonLd,
    text: (document.body?.innerText || '').slice(0, 30000),
  };
}

chrome.action.onClicked.addListener(async (tab) => {
  let capture;
  try {
    const [res] = await chrome.scripting.executeScript({ target: { tabId: tab.id }, func: capturePage });
    capture = res?.result;
  } catch {
    // chrome:// pages, the Web Store, PDFs: the browser will not let us read them.
  }
  if (!capture) capture = { url: tab.url || '', title: tab.title || '', og: {}, jsonLd: [], text: '' };

  const opened = await chrome.tabs.create({ url: IMPORT_URL, index: tab.index + 1 });
  await chrome.storage.session.set({ [`capture:${opened.id}`]: capture });
});

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg?.type !== 'get-capture' || !sender.tab) return;
  const key = `capture:${sender.tab.id}`;
  chrome.storage.session.get(key).then((got) => {
    chrome.storage.session.remove(key);
    sendResponse(got[key] || null);
  });
  return true; // async response
});

chrome.tabs.onRemoved.addListener((tabId) => chrome.storage.session.remove(`capture:${tabId}`));
