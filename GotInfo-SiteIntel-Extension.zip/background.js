// GotInfo — Site Intel extension background service worker
// Minimal — all logic runs in popup.js

chrome.runtime.onInstalled.addListener(() => {
  console.log("GotInfo Site Intel extension installed.");
});
