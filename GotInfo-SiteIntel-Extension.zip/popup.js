/**
 * GotInfo — Site Intel browser extension popup.
 * Fetches RDAP (domain), IP geolocation, DNS, and certificate info
 * for the active tab's hostname.
 */

const GOTINFO = "https://gotinfo.net";

// ── Utilities ──────────────────────────────────────────────────────────────────

function $(id) { return document.getElementById(id); }

function showView(id) {
  ["view-loading", "view-error", "view-main"].forEach((v) => {
    const el = $(v);
    if (el) el.style.display = v === id ? "flex" : "none";
  });
}

function setText(id, text) {
  const el = $(id);
  if (el) el.textContent = text || "—";
}

function fmtDate(str) {
  if (!str) return "—";
  try {
    const d = new Date(str);
    return d.toISOString().slice(0, 10);
  } catch { return str; }
}

function daysUntil(str) {
  if (!str) return null;
  try {
    return Math.floor((new Date(str) - Date.now()) / 86400000);
  } catch { return null; }
}

// ── Active tab ─────────────────────────────────────────────────────────────────

function getActiveTab() {
  return new Promise((resolve) => {
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => resolve(tabs[0]));
  });
}

// ── API calls ──────────────────────────────────────────────────────────────────

async function fetchJSON(url) {
  const res = await fetch(url);
  if (!res.ok) throw new Error(`HTTP ${res.status}`);
  return res.json();
}

/** RDAP domain lookup */
async function fetchRDAP(domain) {
  // Strip to registrable domain (last two parts) for RDAP
  const parts = domain.split(".");
  const registrable = parts.length > 2 ? parts.slice(-2).join(".") : domain;
  const data = await fetchJSON(`https://rdap.org/domain/${registrable}`);
  return data;
}

/** IP geolocation via ip-api.com (free, no key required) */
async function fetchIPGeo(ip) {
  return fetchJSON(`https://ip-api.com/json/${ip}?fields=status,country,regionName,city,isp,org,as,query`);
}

/** DNS over HTTPS via Cloudflare */
async function fetchDNS(domain, type) {
  const data = await fetchJSON(
    `https://cloudflare-dns.com/dns-query?name=${encodeURIComponent(domain)}&type=${type}`,
  );
  return data.Answer || [];
}

/** Resolve A/AAAA records → first IP */
async function resolveIP(domain) {
  try {
    const ans = await fetchDNS(domain, "A");
    if (ans.length) return ans[0].data;
  } catch { /* fallthrough */ }
  try {
    const ans = await fetchDNS(domain, "AAAA");
    if (ans.length) return ans[0].data;
  } catch { /* ignore */ }
  return null;
}

// ── Parsers ────────────────────────────────────────────────────────────────────

function parseRDAP(rdap) {
  const result = {
    registrar: "—",
    created: "—",
    expires: "—",
    updated: "—",
    status: [],
    dnssec: "—",
  };

  // Registrar
  try {
    const entity = rdap.entities?.find((e) => e.roles?.includes("registrar"));
    if (entity?.vcardArray) {
      const fn = entity.vcardArray[1]?.find((f) => f[0] === "fn");
      if (fn) result.registrar = fn[3];
    }
  } catch { /* ignore */ }

  // Dates
  try {
    for (const ev of rdap.events || []) {
      if (ev.eventAction === "registration") result.created = fmtDate(ev.eventDate);
      if (ev.eventAction === "expiration") result.expires = fmtDate(ev.eventDate);
      if (ev.eventAction === "last changed") result.updated = fmtDate(ev.eventDate);
    }
  } catch { /* ignore */ }

  // Status
  try {
    result.status = (rdap.status || []).map((s) =>
      s.replace(/-/g, " ").replace(/\b\w/g, (c) => c.toUpperCase()),
    );
  } catch { /* ignore */ }

  // DNSSEC
  try {
    result.dnssec = rdap.secureDNS?.delegationSigned ? "Signed" : "Unsigned";
  } catch { /* ignore */ }

  return result;
}

// ── Render ─────────────────────────────────────────────────────────────────────

function renderIP(geo, resolvedIP) {
  setText("ip-resolved", resolvedIP || "—");
  if (geo && geo.status === "success") {
    const location = [geo.city, geo.regionName, geo.country].filter(Boolean).join(", ");
    setText("ip-location", location || "—");
    setText("ip-org", geo.org || geo.isp || "—");
    setText("ip-asn", geo.as || "—");
  }
}

function renderWHOIS(rdap) {
  const parsed = parseRDAP(rdap);
  setText("whois-registrar", parsed.registrar);
  setText("whois-created", parsed.created);
  setText("whois-expires", parsed.expires);
  setText("whois-updated", parsed.updated);

  const statusEl = $("whois-status");
  if (parsed.status.length) {
    statusEl.innerHTML = parsed.status
      .slice(0, 3)
      .map((s) => `<span class="dot dot-green"></span>${s}`)
      .join(" &nbsp;");
  } else {
    statusEl.textContent = "—";
  }

  setText("whois-dnssec", parsed.dnssec);

  // Expiry badge
  const days = daysUntil(rdap.events?.find((e) => e.eventAction === "expiration")?.eventDate);
  if (days !== null && days <= 30) {
    const badge = $("whois-expires");
    if (badge) badge.style.color = days <= 7 ? "var(--danger)" : "var(--warning)";
  }
}

function renderDNS(records) {
  const container = $("dns-records");
  if (!container) return;
  container.innerHTML = "";
  const typeOrder = ["A", "AAAA", "MX", "NS", "TXT", "CNAME"];
  const sorted = [...records].sort((a, b) => {
    const ai = typeOrder.indexOf(a.type);
    const bi = typeOrder.indexOf(b.type);
    return (ai === -1 ? 99 : ai) - (bi === -1 ? 99 : bi);
  });

  for (const rec of sorted.slice(0, 12)) {
    const row = document.createElement("div");
    row.className = "dns-row";

    const typeEl = document.createElement("span");
    typeEl.className = "dns-type";
    typeEl.textContent = rec.type;

    const valEl = document.createElement("span");
    valEl.className = "dns-val";
    valEl.textContent = rec.data;
    valEl.title = rec.data;

    row.appendChild(typeEl);
    row.appendChild(valEl);
    container.appendChild(row);
  }

  if (!sorted.length) {
    container.innerHTML = '<span style="font-size:10px;color:var(--text-muted)">No records found</span>';
  }
}

function renderCert(domain, scheme) {
  const certSection = $("section-cert");
  if (scheme !== "https:") {
    if (certSection) certSection.style.display = "none";
    return;
  }
  // We can't read cert details from a browser extension popup directly;
  // show the link to gotinfo.net certs page instead
  setText("cert-cn", domain);
  setText("cert-issuer", "See GotInfo for full cert details");
  setText("cert-from", "—");
  setText("cert-to", "—");

  const badge = $("cert-valid-badge");
  if (badge) {
    badge.textContent = "HTTPS";
    badge.className = "badge badge-valid";
    badge.style.display = "";
  }
}

// ── Main ───────────────────────────────────────────────────────────────────────

async function init() {
  showView("view-loading");

  const tab = await getActiveTab();
  if (!tab?.url) {
    $("error-msg").textContent = "No active tab found.";
    showView("view-error");
    return;
  }

  let url;
  try { url = new URL(tab.url); } catch {
    $("error-msg").textContent = "Cannot inspect this page.";
    showView("view-error");
    return;
  }

  const { hostname, protocol } = url;

  // Block non-web pages
  if (!["http:", "https:"].includes(protocol)) {
    $("error-msg").textContent = "Open a web page to see site intel.";
    showView("view-error");
    return;
  }

  // Update header
  setText("site-domain", hostname);
  const schemeEl = $("site-scheme");
  if (schemeEl) {
    schemeEl.textContent = protocol.replace(":", "");
    schemeEl.className = protocol === "https:" ? "badge badge-scheme" : "badge badge-http";
  }

  // GotInfo deep links
  const domainPageUrl = `${GOTINFO}/domain.html?q=${encodeURIComponent(hostname)}`;
  const certPageUrl   = `${GOTINFO}/certs.html?q=${encodeURIComponent(hostname)}`;
  const asnPageUrl    = `${GOTINFO}/asn.html`;

  const openSiteBtn = $("btn-open-site");
  if (openSiteBtn) openSiteBtn.href = domainPageUrl;

  const whoisLink = $("whois-gotinfo-link");
  if (whoisLink) whoisLink.href = domainPageUrl;

  const certLink = $("cert-gotinfo-link");
  if (certLink) certLink.href = certPageUrl;

  const ipLink = $("ip-gotinfo-link");
  if (ipLink) ipLink.href = asnPageUrl;

  // Fetch data in parallel
  const [rdapResult, ipResult, dnsResult] = await Promise.allSettled([
    fetchRDAP(hostname),
    resolveIP(hostname).then((ip) => ip ? fetchIPGeo(ip).then((geo) => ({ ip, geo })) : null),
    Promise.allSettled(
      ["A", "AAAA", "MX", "NS", "TXT"].map((t) =>
        fetchDNS(hostname, t).then((recs) => recs.map((r) => ({ type: t, data: r.data }))),
      ),
    ).then((results) => results.flatMap((r) => (r.status === "fulfilled" ? r.value : []))),
  ]);

  showView("view-main");

  // IP
  if (ipResult.status === "fulfilled" && ipResult.value) {
    renderIP(ipResult.value.geo, ipResult.value.ip);
  }

  // WHOIS
  if (rdapResult.status === "fulfilled") {
    renderWHOIS(rdapResult.value);
  } else {
    setText("whois-registrar", "RDAP lookup failed");
  }

  // DNS
  renderDNS(dnsResult.status === "fulfilled" ? dnsResult.value : []);

  // Cert
  renderCert(hostname, protocol);
}

init();
