/**
 * MakerManifest service worker (Chrome MV3 / Firefox compatible).
 * Currently minimal — the popup handles all API calls directly.
 */

chrome.runtime.onInstalled.addListener(() => {
  console.log("[MakerManifest] Extension installed.");
});
