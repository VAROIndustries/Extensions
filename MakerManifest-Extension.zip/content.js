/**
 * MakerManifest content script — scrapes product info from the current page.
 * Listens for a message from the popup and responds with extracted data.
 */

function getMetaContent(property) {
  const el = document.querySelector(`meta[property="${property}"], meta[name="${property}"]`);
  return el?.getAttribute("content")?.trim() || null;
}

function extractProductInfo() {
  const url = window.location.href;
  const hostname = window.location.hostname.replace(/^www\./, "");

  // ── Amazon ────────────────────────────────────────────────────────────────
  if (hostname.includes("amazon.")) {
    const title = document.querySelector("#productTitle")?.textContent?.trim()
      || document.querySelector("#title")?.textContent?.trim()
      || getMetaContent("og:title")
      || document.title;

    const imageEl = document.querySelector("#landingImage, #imgBlkFront, #main-image");
    const image = imageEl?.getAttribute("data-old-hires")
      || imageEl?.getAttribute("src")
      || getMetaContent("og:image");

    const price = document.querySelector(".a-price .a-offscreen, #priceblock_ourprice, #priceblock_dealprice, #corePrice_feature_div .a-offscreen")
      ?.textContent?.trim() || null;

    return { url, title, image, price, store: "Amazon" };
  }

  // ── Generic: Open Graph + fallback ────────────────────────────────────────
  const title = getMetaContent("og:title") || document.title || "";
  const image = getMetaContent("og:image") || null;
  const price = getMetaContent("product:price:amount") || getMetaContent("og:price:amount") || null;

  return { url, title, image, price, store: hostname };
}

chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  if (msg.type === "GET_PRODUCT_INFO") {
    sendResponse(extractProductInfo());
  }
  return true;
});
