/**
 * MakerManifest browser extension popup.
 * Authentication: Bearer token stored in chrome.storage.local.
 */

const API = "https://makermanifest.co/api";

// ── Storage helpers ────────────────────────────────────────────────────────────

function getToken() {
  return new Promise((resolve) => {
    chrome.storage.local.get(["mm_token"], (result) => resolve(result.mm_token || null));
  });
}

function setToken(token) {
  return new Promise((resolve) => chrome.storage.local.set({ mm_token: token }, resolve));
}

function clearToken() {
  return new Promise((resolve) => chrome.storage.local.remove(["mm_token"], resolve));
}

function getLastListId() {
  return new Promise((resolve) => {
    chrome.storage.local.get(["mm_last_list"], (result) => resolve(result.mm_last_list || null));
  });
}

function setLastListId(id) {
  return new Promise((resolve) => chrome.storage.local.set({ mm_last_list: id }, resolve));
}

function getLastSectionId(kitId) {
  return new Promise((resolve) => {
    chrome.storage.local.get([`mm_last_section_${kitId}`], (result) => resolve(result[`mm_last_section_${kitId}`] || null));
  });
}

function setLastSectionId(kitId, sectionId) {
  return new Promise((resolve) => chrome.storage.local.set({ [`mm_last_section_${kitId}`]: sectionId }, resolve));
}

// ── API helpers ────────────────────────────────────────────────────────────────

async function apiGet(path, token) {
  const res = await fetch(`${API}${path}`, {
    headers: { Authorization: `Bearer ${token}` },
  });
  if (!res.ok) throw new Error((await res.json().catch(() => ({}))).error || `HTTP ${res.status}`);
  return res.json();
}

async function apiPost(path, token, body) {
  const res = await fetch(`${API}${path}`, {
    method: "POST",
    headers: { Authorization: `Bearer ${token}`, "Content-Type": "application/json" },
    body: JSON.stringify(body),
  });
  if (!res.ok) throw new Error((await res.json().catch(() => ({}))).error || `HTTP ${res.status}`);
  return res.json();
}

// ── View management ────────────────────────────────────────────────────────────

function showView(id) {
  document.querySelectorAll(".view").forEach((el) => (el.style.display = "none"));
  document.getElementById(id).style.display = "flex";
}

function setError(elId, msg) {
  const el = document.getElementById(elId);
  el.textContent = msg;
  el.style.display = msg ? "block" : "none";
}

// ── Product info ───────────────────────────────────────────────────────────────

let currentProductInfo = null;
let currentLists = [];

async function loadProductInfo() {
  return new Promise((resolve) => {
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      const tab = tabs[0];
      if (!tab?.id) return resolve({ url: "", title: tab?.title || "", image: null, price: null });

      chrome.tabs.sendMessage(tab.id, { type: "GET_PRODUCT_INFO" }, (response) => {
        if (chrome.runtime.lastError || !response) {
          // Content script not ready — fall back to tab info
          resolve({ url: tab.url || "", title: tab.title || "", image: null, price: null });
        } else {
          resolve(response);
        }
      });
    });
  });
}

function renderProductPreview(info) {
  const title = info.title || info.url;
  const shortUrl = (() => {
    try { return new URL(info.url).hostname.replace(/^www\./, ""); } catch { return info.url; }
  })();

  document.getElementById("product-title").textContent = title;
  document.getElementById("product-url").textContent = shortUrl;

  const imgEl = document.getElementById("product-image");
  if (info.image) {
    imgEl.src = info.image;
    imgEl.style.display = "block";
    imgEl.onerror = () => { imgEl.style.display = "none"; };
  }

  const priceEl = document.getElementById("product-price");
  if (info.price) {
    priceEl.textContent = info.price;
    priceEl.style.display = "block";
  }

  // Pre-fill title override with product title (user can clear if they want)
  document.getElementById("input-title").value = title;
}

async function renderSections(kitId, lists) {
  const list = lists.find((l) => l.id === kitId);
  const wrap = document.getElementById("section-wrap");
  const sel = document.getElementById("select-section");
  sel.innerHTML = "";

  if (!list || !list.sections || list.sections.length === 0) {
    wrap.style.display = "none";
    return;
  }

  wrap.style.display = "block";
  const none = document.createElement("option");
  none.value = "";
  none.textContent = "— No section —";
  sel.appendChild(none);

  for (const s of list.sections) {
    const opt = document.createElement("option");
    opt.value = s.id;
    opt.textContent = s.name;
    sel.appendChild(opt);
  }

  const lastSectionId = await getLastSectionId(kitId);
  if (lastSectionId && list.sections.some((s) => s.id === lastSectionId)) {
    sel.value = lastSectionId;
  }
}

async function renderLists(lists) {
  const sel = document.getElementById("select-list");
  sel.innerHTML = "";
  if (!lists.length) {
    sel.innerHTML = '<option value="">No lists found — create one in the dashboard</option>';
    document.getElementById("section-wrap").style.display = "none";
    return;
  }
  const lastId = await getLastListId();
  for (const list of lists) {
    const opt = document.createElement("option");
    opt.value = list.id;
    opt.textContent = list.title + (list.isPublished ? "" : " (draft)");
    sel.appendChild(opt);
  }
  // Restore last used list if it still exists
  if (lastId && lists.some((l) => l.id === lastId)) {
    sel.value = lastId;
  }
  // Render sections for the currently selected list
  await renderSections(sel.value, lists);
  // Update sections when list changes
  sel.addEventListener("change", () => renderSections(sel.value, lists));
}

// ── Main flow ──────────────────────────────────────────────────────────────────

async function initConnected(token) {
  showView("view-loading");
  document.getElementById("btn-logout").style.display = "flex";

  try {
    const [{ lists }, info] = await Promise.all([
      apiGet("/extension/lists", token),
      loadProductInfo(),
    ]);

    currentLists = lists;
    currentProductInfo = info;

    renderProductPreview(info);
    renderLists(lists);
    showView("view-add");
  } catch (err) {
    // Token may be revoked — go back to connect screen
    await clearToken();
    showConnect();
  }
}

function showConnect() {
  document.getElementById("btn-logout").style.display = "none";
  showView("view-connect");
}

async function init() {
  showView("view-loading");
  const token = await getToken();
  if (token) {
    await initConnected(token);
  } else {
    showConnect();
  }
}

// ── Event handlers ─────────────────────────────────────────────────────────────

document.getElementById("btn-connect").addEventListener("click", async () => {
  const token = document.getElementById("input-token").value.trim();
  if (!token) return;

  const btn = document.getElementById("btn-connect");
  btn.disabled = true;
  btn.textContent = "Connecting…";
  setError("connect-error", "");

  try {
    await apiGet("/extension/me", token);
    await setToken(token);
    await initConnected(token);
  } catch (err) {
    setError("connect-error", err.message === "Unauthorized" ? "Invalid token — check your token in Dashboard → Settings." : err.message);
    btn.disabled = false;
    btn.textContent = "Connect Account";
  }
});

document.getElementById("btn-logout").addEventListener("click", async () => {
  await clearToken();
  document.getElementById("input-token").value = "";
  showConnect();
});

document.getElementById("btn-add").addEventListener("click", async () => {
  const token = await getToken();
  const kitId = document.getElementById("select-list").value;
  if (!kitId || !currentProductInfo) return;

  const sectionId = document.getElementById("select-section").value || undefined;
  const titleOverride = document.getElementById("input-title").value.trim();
  const btn = document.getElementById("btn-add");
  btn.disabled = true;
  btn.textContent = "Adding…";
  setError("add-error", "");

  try {
    await apiPost("/extension/items", token, {
      kitId,
      url: currentProductInfo.url,
      title: titleOverride || undefined,
      image: currentProductInfo.image || undefined,
      sectionId,
    });
    await setLastListId(kitId);
    if (sectionId) await setLastSectionId(kitId, sectionId);
    showView("view-success");
  } catch (err) {
    setError("add-error", err.message || "Something went wrong. Please try again.");
    btn.disabled = false;
    btn.textContent = "Add to List";
  }
});

document.getElementById("btn-add-another").addEventListener("click", async () => {
  const token = await getToken();
  renderProductPreview(currentProductInfo);
  renderLists(currentLists);
  showView("view-add");
});

// ── Start ──────────────────────────────────────────────────────────────────────
init();
