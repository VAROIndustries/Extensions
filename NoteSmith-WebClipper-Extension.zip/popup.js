/**
 * NoteSmith Web Clipper — popup.
 *
 * Auth: a "clip only" API key (Settings → API Keys) held in chrome.storage.local. That key
 * class can create notes and list workspaces/folders — it cannot read or modify existing
 * documents, which is why it is safe to leave sitting in a browser profile.
 */

const API = "https://notesmith.io/api/v1";
const APP = "https://notesmith.io";

const escapeHtml = (text) => String(text).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
const escapeAttr = (text) => escapeHtml(text).replace(/"/g, "&quot;");

// ── Storage ───────────────────────────────────────────────────────────────────

const store = {
  get: (keys) => new Promise((resolve) => chrome.storage.local.get(keys, resolve)),
  set: (values) => new Promise((resolve) => chrome.storage.local.set(values, resolve)),
  remove: (keys) => new Promise((resolve) => chrome.storage.local.remove(keys, resolve)),
};

// ── API ───────────────────────────────────────────────────────────────────────

class ApiError extends Error {
  constructor(message, status) {
    super(message);
    this.status = status;
  }
}

async function api(path, token, options = {}) {
  let res;
  try {
    res = await fetch(`${API}${path}`, {
      ...options,
      headers: { Authorization: `Bearer ${token}`, ...(options.body ? { "Content-Type": "application/json" } : {}) },
    });
  } catch {
    throw new ApiError("Can't reach NoteSmith. Check your connection.", 0);
  }
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new ApiError(data.error ?? `HTTP ${res.status}`, res.status);
  return data;
}

// ── View helpers ──────────────────────────────────────────────────────────────

const $ = (id) => document.getElementById(id);

function showView(id) {
  document.querySelectorAll(".view").forEach((el) => { el.style.display = "none"; });
  $(id).style.display = "flex";
}

function setError(id, message) {
  const el = $(id);
  el.textContent = message ?? "";
  el.style.display = message ? "block" : "none";
}

// ── State ─────────────────────────────────────────────────────────────────────

let clipInfo = { title: "", url: "", hasSelection: false };
let workspaces = [];

// ── Page info ─────────────────────────────────────────────────────────────────

function activeTab() {
  return new Promise((resolve) => chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => resolve(tabs[0])));
}

/**
 * Inject the clipper into the tab, then ask it for the page. The script is not declared in
 * the manifest, so this is what grants access — and only for the tab the user acted on.
 * Fails quietly on pages no extension may touch (chrome://, the Web Store, the PDF viewer).
 */
async function askTab(tabId, message) {
  try {
    await chrome.scripting.executeScript({ target: { tabId }, files: ["content.js"] });
  } catch {
    return null;
  }
  return new Promise((resolve) => {
    chrome.tabs.sendMessage(tabId, message, (response) => {
      // lastError must be read, or Chrome logs "Unchecked runtime.lastError".
      resolve(chrome.runtime.lastError ? null : response);
    });
  });
}

async function loadClipInfo() {
  const tab = await activeTab();
  if (!tab?.id) return { title: "", url: "", hasSelection: false };
  const info = await askTab(tab.id, { type: "CLIP_INFO" });
  // No content script (chrome:// page, PDF viewer, or a tab opened before install) — fall
  // back to what the tab itself reports so the user still gets a bookmark-style clip.
  return info ?? { title: tab.title ?? "", url: tab.url ?? "", hasSelection: false };
}

// ── Destination selects ───────────────────────────────────────────────────────

function fillSelect(select, options, selected) {
  select.innerHTML = "";
  for (const { value, label } of options) {
    const opt = document.createElement("option");
    opt.value = value;
    opt.textContent = label;
    select.appendChild(opt);
  }
  if (selected && options.some((o) => o.value === selected)) select.value = selected;
}

/** Folders come back flat with parentId — indent them so nesting is readable. */
function folderOptions(folders) {
  const byParent = new Map();
  for (const folder of folders) {
    const key = folder.parentId ?? "root";
    if (!byParent.has(key)) byParent.set(key, []);
    byParent.get(key).push(folder);
  }
  // The indent below is U+00A0, not a space: ordinary leading whitespace in an <option>
  // collapses, which would render every level of the tree flush left.
  const options = [{ value: "", label: "— No folder —" }];
  const walk = (parent, depth) => {
    for (const folder of byParent.get(parent) ?? []) {
      options.push({ value: folder.id, label: `${"  ".repeat(depth)}${folder.name}` });
      walk(folder.id, depth + 1);
    }
  };
  walk("root", 0);
  return options;
}

async function loadFolders(token, workspaceId) {
  const select = $("select-folder");
  fillSelect(select, [{ value: "", label: "Loading…" }]);
  try {
    const { folders } = await api(`/folders?workspaceId=${encodeURIComponent(workspaceId)}`, token);
    const { ns_last_folder: lastFolder } = await store.get(["ns_last_folder"]);
    fillSelect(select, folderOptions(folders), lastFolder);
  } catch {
    // A folder list we could not fetch must not block clipping — the note just lands at root.
    fillSelect(select, [{ value: "", label: "— No folder —" }]);
  }
}

// ── Main flow ─────────────────────────────────────────────────────────────────

async function initConnected(token) {
  showView("view-loading");
  $("btn-logout").style.display = "block";

  try {
    const [{ workspaces: list }, info] = await Promise.all([api("/workspaces", token), loadClipInfo()]);
    workspaces = list;
    clipInfo = info;

    $("clip-title-preview").textContent = info.title || info.url;
    $("clip-url").textContent = (() => {
      try { return new URL(info.url).hostname.replace(/^www\./, ""); } catch { return info.url; }
    })();
    $("input-title").value = info.title || info.url;
    $("btn-clip-selection").disabled = !info.hasSelection;

    const { ns_last_workspace: lastWorkspace } = await store.get(["ns_last_workspace"]);
    fillSelect($("select-workspace"), workspaces.map((w) => ({ value: w.id, label: w.name })), lastWorkspace);

    showView("view-clip");
    if ($("select-workspace").value) await loadFolders(token, $("select-workspace").value);
  } catch (err) {
    if (err.status === 401) {
      // Revoked or mistyped key — drop it rather than leave the popup half-authenticated.
      await store.remove(["ns_token"]);
      showConnect();
    } else {
      showView("view-clip");
      setError("clip-error", err.message);
    }
  }
}

function showConnect() {
  $("btn-logout").style.display = "none";
  setError("connect-error", "");
  showView("view-connect");
}

async function init() {
  showView("view-loading");
  const { ns_token: token } = await store.get(["ns_token"]);
  if (token) await initConnected(token);
  else showConnect();
}

// ── Clipping ──────────────────────────────────────────────────────────────────

async function doClip(selectionOnly) {
  const { ns_token: token } = await store.get(["ns_token"]);
  const workspaceId = $("select-workspace").value;
  if (!token || !workspaceId) return;

  // null, never undefined: JSON.stringify drops undefined keys, and POST /api/v1/docs reads
  // an ABSENT folderId as "use the account's API-inbox default folder". Omitting it filed
  // clips into that folder even when the user had explicitly picked "No folder".
  const folderId = $("select-folder").value || null;
  const buttons = [$("btn-clip-page"), $("btn-clip-selection")];
  buttons.forEach((b) => { b.disabled = true; });
  $("btn-clip-page").textContent = "Clipping…";
  setError("clip-error", "");

  try {
    const tab = await activeTab();
    const clipped = tab?.id ? await askTab(tab.id, { type: "CLIP", selectionOnly }) : null;
    const sourceUrl = clipped?.url || clipInfo.url;
    // Provenance travels with the note — a clip with no source is a clip you can't check.
    // Escaped even though browsers percent-encode < > " during URL serialization: this is the
    // one place a page-controlled string is interpolated into markup.
    const html = `<blockquote>Clipped from <a href="${escapeAttr(sourceUrl)}">${escapeHtml(sourceUrl)}</a></blockquote>\n${clipped?.html ?? ""}`;

    const doc = await api("/docs", token, {
      method: "POST",
      body: JSON.stringify({
        workspaceId,
        folderId,   // explicit null = workspace root
        title: ($("input-title").value.trim() || clipInfo.title || sourceUrl).slice(0, 500),
        contentHtml: html,
      }),
    });

    await store.set({ ns_last_workspace: workspaceId });
    // "No folder" is a choice like any other — remembering the previous folder instead would
    // quietly re-file the next clip somewhere the user just opted out of.
    if (folderId) await store.set({ ns_last_folder: folderId });
    else await store.remove(["ns_last_folder"]);
    $("link-open-note").href = `${APP}/docs/${doc.id}`;
    showView("view-success");
  } catch (err) {
    if (err.status === 401) {
      await store.remove(["ns_token"]);
      showConnect();
      setError("connect-error", "That token is no longer valid — paste a new one.");
    } else {
      setError("clip-error", err.message);
    }
  } finally {
    buttons.forEach((b) => { b.disabled = false; });
    $("btn-clip-selection").disabled = !clipInfo.hasSelection;
    $("btn-clip-page").textContent = "Clip page";
  }
}

// ── Events ────────────────────────────────────────────────────────────────────

$("btn-connect").addEventListener("click", async () => {
  const token = $("input-token").value.trim();
  if (!token) return;

  const button = $("btn-connect");
  button.disabled = true;
  button.textContent = "Connecting…";
  setError("connect-error", "");

  try {
    const me = await api("/me", token);  // validate before storing
    // A full-access key authenticates here just as happily as a clip key, so accepting it
    // silently would put a read/write/delete credential in chrome.storage.local — an
    // unencrypted file on disk — while the user believes the extension is create-only.
    if (me.scope !== "clip") {
      setError("connect-error", "That's a full-access key. Create one with the “Browser extension (clip only)” scope in Settings → API Keys and paste that instead.");
      return;
    }
    await store.set({ ns_token: token });
    $("input-token").value = "";
    await initConnected(token);
  } catch (err) {
    setError("connect-error", err.status === 401
      ? "That token was rejected. Make sure it's a clip-only key from Settings → API Keys."
      : err.message);
  } finally {
    button.disabled = false;
    button.textContent = "Connect";
  }
});

$("btn-logout").addEventListener("click", async () => {
  await store.remove(["ns_token"]);
  showConnect();
});

$("select-workspace").addEventListener("change", async () => {
  const { ns_token: token } = await store.get(["ns_token"]);
  if (token) await loadFolders(token, $("select-workspace").value);
});

$("btn-clip-page").addEventListener("click", () => doClip(false));
$("btn-clip-selection").addEventListener("click", () => doClip(true));
$("btn-clip-another").addEventListener("click", () => { showView("view-clip"); });

init();
