/**
 * NoteSmith Web Clipper — content script.
 *
 * Owns everything that needs a live DOM: picking the region worth clipping, dropping the
 * furniture around it, and serializing what is left.
 *
 * The output contract matters. NoteSmith's server-side htmlToTiptapJson() is regex-based
 * (there is no DOM on the server), so it understands a FLAT sequence of block tags:
 *
 *   h1-h6 | p | blockquote | pre | ul/ol (with li) | img
 *
 * carrying only inline strong/em/code/s/u/a/br inside. Anything else is unwrapped to its text
 * here rather than left for a regex to guess at. In particular, images are hoisted OUT of the
 * blocks that contain them: a <p> match on the server consumes its whole inner HTML, so an
 * <img> nested inside one would vanish silently.
 */

// Injected on demand (chrome.scripting.executeScript), not declared in the manifest — the
// extension therefore asks for access to a page only when you actually clip from it, instead
// of "read and change all your data on all websites" at install time. Injection can repeat on
// the same tab, so everything lives in an IIFE: re-running a top-level `const` in the same
// isolated world would throw "Identifier has already been declared" on the second clip.
(() => {

const DROP_TAGS = new Set([
  "SCRIPT", "STYLE", "NOSCRIPT", "IFRAME", "SVG", "CANVAS", "VIDEO", "AUDIO", "OBJECT", "EMBED",
  "NAV", "ASIDE", "FOOTER", "HEADER", "FORM", "BUTTON", "INPUT", "SELECT", "TEXTAREA", "LABEL",
  "LINK", "META", "TEMPLATE", "DIALOG",
]);

const HEADINGS = new Set(["H1", "H2", "H3", "H4", "H5", "H6"]);

/** Inline tags the server understands, mapped to what we emit. */
const INLINE_TAGS = {
  STRONG: "strong", B: "strong",
  EM: "em", I: "em",
  CODE: "code",
  S: "s", DEL: "s", STRIKE: "s",
  U: "u",
  A: "a",
};

function escapeHtml(text) {
  return text.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
}

function escapeAttr(value) {
  return escapeHtml(value).replace(/"/g, "&quot;");
}

/** Absolute URL, or null when the scheme is one we refuse to store. */
function safeUrl(raw) {
  if (!raw) return null;
  let url;
  try {
    url = new URL(raw, document.baseURI);
  } catch {
    return null;
  }
  return /^(https?|mailto):$/i.test(url.protocol) ? url.href : null;
}

/**
 * Hidden nodes are skipped — a clip should contain what the reader sees, not the three
 * collapsed menus and the cookie banner behind it. Only meaningful for live nodes; a
 * selection fragment is detached and has no computed style, and is visible by definition.
 */
function isHidden(el) {
  if (!el.isConnected) return false;
  if (el.hasAttribute("hidden") || el.getAttribute("aria-hidden") === "true") return true;
  const style = getComputedStyle(el);
  return style.display === "none" || style.visibility === "hidden" || style.opacity === "0";
}

function skip(el) {
  return DROP_TAGS.has(el.tagName) || isHidden(el);
}

// ── Inline serialization ──────────────────────────────────────────────────────

function inlineHtml(node) {
  let out = "";
  for (const child of node.childNodes) {
    if (child.nodeType === Node.TEXT_NODE) {
      out += escapeHtml(child.nodeValue.replace(/\s+/g, " "));
      continue;
    }
    if (child.nodeType !== Node.ELEMENT_NODE) continue;
    if (skip(child)) continue;
    if (child.tagName === "BR") { out += "<br>"; continue; }
    if (child.tagName === "IMG") continue; // hoisted separately as a block

    const tag = INLINE_TAGS[child.tagName];
    if (tag === "a") {
      const href = safeUrl(child.getAttribute("href"));
      const inner = inlineHtml(child);
      out += href ? `<a href="${escapeAttr(href)}">${inner}</a>` : inner;
    } else if (tag) {
      out += `<${tag}>${inlineHtml(child)}</${tag}>`;
    } else {
      out += inlineHtml(child); // unknown wrapper — keep the text, drop the tag
    }
  }
  return out;
}

function imgHtml(el) {
  // Lazy-loaded images often park the real URL in data-src and leave src as a placeholder.
  const src = safeUrl(el.getAttribute("src") || el.getAttribute("data-src") || el.dataset.original);
  if (!src) return "";
  const alt = el.getAttribute("alt");
  return `<img src="${escapeAttr(src)}"${alt ? ` alt="${escapeAttr(alt)}"` : ""}>`;
}

/** Images anywhere under a block, emitted as their own top-level blocks after it. */
function nestedImages(el) {
  return [...el.querySelectorAll("img")].filter((img) => !skip(img)).map(imgHtml).filter(Boolean);
}

// ── Block serialization ───────────────────────────────────────────────────────

function listHtml(el) {
  const items = [];
  const extra = [];
  for (const li of el.children) {
    if (li.tagName !== "LI" || skip(li)) continue;
    const inner = inlineHtml(li).trim();
    if (inner) items.push(`<li>${inner}</li>`);
    // Nested lists become their own top-level list — the server flattens either way, and this
    // keeps their items from being swallowed by the parent <li>'s inline text.
    for (const sub of li.querySelectorAll(":scope > ul, :scope > ol")) {
      if (!skip(sub)) extra.push(listHtml(sub));
    }
    extra.push(...nestedImages(li));
  }
  const tag = el.tagName === "OL" ? "ol" : "ul";
  return [items.length ? `<${tag}>${items.join("")}</${tag}>` : "", ...extra].filter(Boolean).join("");
}

function emitBlocks(root, out) {
  for (const child of root.childNodes) {
    if (child.nodeType === Node.TEXT_NODE) {
      const text = child.nodeValue.replace(/\s+/g, " ").trim();
      if (text) out.push(`<p>${escapeHtml(text)}</p>`);
      continue;
    }
    if (child.nodeType !== Node.ELEMENT_NODE) continue;
    if (skip(child)) continue;

    const tag = child.tagName;

    if (tag === "IMG") {
      const html = imgHtml(child);
      if (html) out.push(html);
    } else if (HEADINGS.has(tag)) {
      const inner = inlineHtml(child).trim();
      if (inner) out.push(`<${tag.toLowerCase()}>${inner}</${tag.toLowerCase()}>`);
      out.push(...nestedImages(child));
    } else if (tag === "P" || tag === "FIGCAPTION" || tag === "DD" || tag === "DT") {
      const inner = inlineHtml(child).trim();
      if (inner) out.push(`<p>${inner}</p>`);
      out.push(...nestedImages(child));
    } else if (tag === "BLOCKQUOTE") {
      const inner = inlineHtml(child).trim();
      if (inner) out.push(`<blockquote>${inner}</blockquote>`);
      out.push(...nestedImages(child));
    } else if (tag === "PRE") {
      const text = child.textContent;
      if (text.trim()) out.push(`<pre>${escapeHtml(text)}</pre>`);
    } else if (tag === "UL" || tag === "OL") {
      const html = listHtml(child);
      if (html) out.push(html);
    } else if (tag === "HR") {
      // No horizontal rule in the server's block set — skip rather than emit an empty <p>.
      continue;
    } else if (tag === "TABLE") {
      // Tables have no server-side equivalent either. Flatten each row to one paragraph so
      // the data survives even though the grid does not.
      for (const row of child.querySelectorAll("tr")) {
        if (skip(row)) continue;
        const cells = [...row.children].filter((c) => !skip(c)).map((c) => inlineHtml(c).trim()).filter(Boolean);
        if (cells.length) out.push(`<p>${cells.join(" — ")}</p>`);
      }
    } else {
      emitBlocks(child, out); // container — recurse
    }
  }
}

// ── Region selection ──────────────────────────────────────────────────────────

function selectionFragment() {
  const sel = window.getSelection();
  if (!sel || sel.isCollapsed || sel.rangeCount === 0) return null;
  const frag = document.createDocumentFragment();
  for (let i = 0; i < sel.rangeCount; i++) frag.appendChild(sel.getRangeAt(i).cloneContents());
  return frag.textContent.trim() ? frag : null;
}

/**
 * The article, as best we can tell. Scores candidates by how much text they hold against how
 * much of it is link text — the cheap signal that separates prose from a list of other links.
 * textContent rather than innerText on purpose: innerText forces layout on every candidate.
 */
function pickMain() {
  const explicit = document.querySelector("article, main, [role='main']");
  if (explicit && explicit.textContent.trim().length > 200) return explicit;

  let best = null;
  let bestScore = 0;
  for (const el of document.querySelectorAll("div, section, td")) {
    // Cheap structural filters first — getComputedStyle inside skip() forces style resolution,
    // and a big page has thousands of divs.
    if (el.querySelectorAll(":scope > p").length < 2) continue;
    const textLength = el.textContent.trim().length;
    if (textLength < 200) continue;
    if (skip(el)) continue;
    let linkLength = 0;
    for (const a of el.querySelectorAll("a")) linkLength += a.textContent.length;
    const score = textLength - linkLength * 2;
    if (score > bestScore) { bestScore = score; best = el; }
  }
  return best ?? document.body;
}

// ── Message handling ──────────────────────────────────────────────────────────

function clip(selectionOnly) {
  const region = selectionOnly ? selectionFragment() : pickMain();
  const blocks = [];
  if (region) emitBlocks(region, blocks);
  return {
    title: document.title || location.hostname,
    url: location.href,
    html: blocks.join("\n"),
    hasSelection: !!selectionFragment(),
  };
}

// Registered once per tab however many times the file is injected — a second listener would
// answer the same message twice and Chrome would drop the response.
if (!window.__notesmithClipperReady) {
  window.__notesmithClipperReady = true;
  chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
    if (msg?.type === "CLIP_INFO") {
      sendResponse({ title: document.title || location.hostname, url: location.href, hasSelection: !!selectionFragment() });
    } else if (msg?.type === "CLIP") {
      sendResponse(clip(!!msg.selectionOnly));
    }
    return false; // responses are synchronous
  });
}

})();
