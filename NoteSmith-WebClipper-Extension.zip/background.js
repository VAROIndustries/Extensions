/**
 * NoteSmith Web Clipper — service worker.
 *
 * Owns the right-click path: "Clip selection to NoteSmith" posts straight into the last
 * destination the popup used, with no UI. Self-contained on purpose — an MV3 service worker
 * is torn down and restarted constantly, and a shared module would buy nothing over the
 * dozen lines of fetch below.
 */

const API = "https://notesmith.io/api/v1";
const MENU_ID = "notesmith-clip-selection";

chrome.runtime.onInstalled.addListener(() => {
  chrome.contextMenus.create({
    id: MENU_ID,
    title: "Clip selection to NoteSmith",
    contexts: ["selection"],
  });
});

function notify(message) {
  chrome.notifications.create({
    type: "basic",
    iconUrl: "icons/icon48.png",
    title: "NoteSmith Web Clipper",
    message,
  });
}

const escapeHtml = (text) => String(text).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
const escapeAttr = (text) => escapeHtml(text).replace(/"/g, "&quot;");

/** Inject the clipper (not a manifest content script), then ask it for the selection. */
async function askTab(tabId, message) {
  try {
    await chrome.scripting.executeScript({ target: { tabId }, files: ["content.js"] });
  } catch {
    return null;
  }
  return new Promise((resolve) => {
    chrome.tabs.sendMessage(tabId, message, (response) => {
      resolve(chrome.runtime.lastError ? null : response);
    });
  });
}

chrome.contextMenus.onClicked.addListener(async (info, tab) => {
  if (info.menuItemId !== MENU_ID || !tab?.id) return;

  const { ns_token: token, ns_last_workspace: workspaceId, ns_last_folder: folderId } =
    await chrome.storage.local.get(["ns_token", "ns_last_workspace", "ns_last_folder"]);

  if (!token) return notify("Connect the extension first — click the NoteSmith icon.");
  // The right-click path has no destination picker, so it needs one the popup already chose.
  if (!workspaceId) return notify("Clip once from the extension popup first to pick a workspace.");

  const clipped = await askTab(tab.id, { type: "CLIP", selectionOnly: true });
  const sourceUrl = clipped?.url || tab.url || "";
  // Fall back to the plain selection text when the content script is unavailable: better a
  // rough clip than none.
  const body = clipped?.html || `<p>${escapeHtml(info.selectionText ?? "")}</p>`;

  try {
    const res = await fetch(`${API}/docs`, {
      method: "POST",
      headers: { Authorization: `Bearer ${token}`, "Content-Type": "application/json" },
      body: JSON.stringify({
        workspaceId,
        // Explicit null, not an omitted key: an absent folderId means "use the account's
        // API-inbox default folder" server-side, which is not what "no folder" means here.
        folderId: folderId ?? null,
        title: (clipped?.title || tab.title || sourceUrl).slice(0, 500),
        contentHtml: `<blockquote>Clipped from <a href="${escapeAttr(sourceUrl)}">${escapeHtml(sourceUrl)}</a></blockquote>\n${body}`,
      }),
    });
    if (res.status === 401) {
      await chrome.storage.local.remove(["ns_token"]);
      return notify("Your clip token was rejected — reconnect from the extension popup.");
    }
    if (!res.ok) {
      const data = await res.json().catch(() => ({}));
      return notify(data.error ?? `Clip failed (HTTP ${res.status}).`);
    }
    notify("Selection clipped to NoteSmith.");
  } catch {
    notify("Can't reach NoteSmith. Check your connection.");
  }
});
